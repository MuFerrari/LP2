﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C;

        private void tbxB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(tbxB.Text, out B) || (B <= 0))
            {
                errpB.SetError(tbxB, "Número inválido!");
                tbxB.Focus();
            }
            else
                errpB.SetError(tbxB, "");

            // Validação da TextBox "Valor B". O comando está conferindo se o usúario realmente digitou um número. 

        }

        private void tbxC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(tbxC.Text, out C) || (C <= 0))
            {
                errpC.SetError(tbxC, "Número inválido!");
                tbxC.Focus();
            }
            else
                errpC.SetError(tbxC, "");

            // Validação da TextBox "Valor C". O comando está conferindo se o usúario realmente digitou um número. 
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            if ((A < B + C) && (A > Math.Abs(B - C)) &&
                (B < A + C) && (B > Math.Abs(A - C)) &&
                (C < A + B) && (C > Math.Abs(A - B)))
            {
                if ((A == B) && (B == C))
                {
                    MessageBox.Show("É um Triângulo Equilátero");
                }
                else if ((A == B) || (A == C) || (B == C))
                {
                    MessageBox.Show("É um Triângulo Isósceles");
                }
                else
                {
                    MessageBox.Show("É um Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Os Valores Declarados Não Formam um Triângulo");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            tbxA.Clear();
            tbxB.Clear();
            tbxC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void tbxA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(tbxA.Text, out A) || (A <= 0))
            {
                errpA.SetError(tbxA, "Número inválido!");
                tbxA.Focus();
            }
            else
                errpA.SetError(tbxA, "");

            // Validação da TextBox "Valor A". O comando está conferindo se o usúario realmente digitou um número. 

        }


    }
}
