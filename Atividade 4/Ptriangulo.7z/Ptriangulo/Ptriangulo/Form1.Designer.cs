﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.tbxA = new System.Windows.Forms.TextBox();
            this.tbxB = new System.Windows.Forms.TextBox();
            this.tbxC = new System.Windows.Forms.TextBox();
            this.btnExec = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.imgClassificação = new System.Windows.Forms.PictureBox();
            this.errpA = new System.Windows.Forms.ErrorProvider(this.components);
            this.errpB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errpC = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.imgClassificação)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpC)).BeginInit();
            this.SuspendLayout();
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(63, 55);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(127, 20);
            this.lblA.TabIndex = 0;
            this.lblA.Text = "Valor do Lado A:";
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(63, 129);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(127, 20);
            this.lblB.TabIndex = 1;
            this.lblB.Text = "Valor do Lado B:";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(63, 212);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(127, 20);
            this.lblC.TabIndex = 2;
            this.lblC.Text = "Valor do Lado C:";
            // 
            // tbxA
            // 
            this.tbxA.Location = new System.Drawing.Point(225, 55);
            this.tbxA.Name = "tbxA";
            this.tbxA.Size = new System.Drawing.Size(157, 26);
            this.tbxA.TabIndex = 1;
            this.tbxA.Validated += new System.EventHandler(this.tbxA_Validated);
            // 
            // tbxB
            // 
            this.tbxB.Location = new System.Drawing.Point(225, 129);
            this.tbxB.Name = "tbxB";
            this.tbxB.Size = new System.Drawing.Size(157, 26);
            this.tbxB.TabIndex = 2;
            this.tbxB.Validated += new System.EventHandler(this.tbxB_Validated);
            // 
            // tbxC
            // 
            this.tbxC.Location = new System.Drawing.Point(225, 212);
            this.tbxC.Name = "tbxC";
            this.tbxC.Size = new System.Drawing.Size(157, 26);
            this.tbxC.TabIndex = 3;
            this.tbxC.Validated += new System.EventHandler(this.tbxC_Validated);
            // 
            // btnExec
            // 
            this.btnExec.Location = new System.Drawing.Point(101, 380);
            this.btnExec.Name = "btnExec";
            this.btnExec.Size = new System.Drawing.Size(121, 41);
            this.btnExec.TabIndex = 4;
            this.btnExec.Text = "EXECUTAR";
            this.btnExec.UseVisualStyleBackColor = true;
            this.btnExec.Click += new System.EventHandler(this.btnExec_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(324, 380);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(102, 41);
            this.btnSair.TabIndex = 5;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(518, 380);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(103, 41);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // imgClassificação
            // 
            this.imgClassificação.Image = ((System.Drawing.Image)(resources.GetObject("imgClassificação.Image")));
            this.imgClassificação.Location = new System.Drawing.Point(447, 55);
            this.imgClassificação.Name = "imgClassificação";
            this.imgClassificação.Size = new System.Drawing.Size(319, 193);
            this.imgClassificação.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgClassificação.TabIndex = 7;
            this.imgClassificação.TabStop = false;
            // 
            // errpA
            // 
            this.errpA.ContainerControl = this;
            // 
            // errpB
            // 
            this.errpB.ContainerControl = this;
            // 
            // errpC
            // 
            this.errpC.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.imgClassificação);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnExec);
            this.Controls.Add(this.tbxC);
            this.Controls.Add(this.tbxB);
            this.Controls.Add(this.tbxA);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.Name = "Form1";
            this.Text = "TIPO DE TRIÂNGULO";
            ((System.ComponentModel.ISupportInitialize)(this.imgClassificação)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errpC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.TextBox tbxA;
        private System.Windows.Forms.TextBox tbxB;
        private System.Windows.Forms.TextBox tbxC;
        private System.Windows.Forms.Button btnExec;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.PictureBox imgClassificação;
        private System.Windows.Forms.ErrorProvider errpA;
        private System.Windows.Forms.ErrorProvider errpB;
        private System.Windows.Forms.ErrorProvider errpC;
    }
}

