﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int numero1;
            int numero2;
            if (!int.TryParse(txtNum1.Text, out numero1) || !int.TryParse(txtNum2.Text, out numero2) || (numero1 >= numero2))
                MessageBox.Show("Dados Inválidos!");

            else
            {
                Random obj1 = new Random();
                int Sorteado = obj1.Next(numero1, numero2);
                MessageBox.Show($"Número sorteado: {Sorteado}");
            }

        }
    }
}
