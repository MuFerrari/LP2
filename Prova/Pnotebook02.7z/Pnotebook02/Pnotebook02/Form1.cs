﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[2, 3];

            string saida = "";
            string saida2 = "";
            string valor = "";

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    valor = Interaction.InputBox("Insira o valor do notebook " + (i + 1) + " na loja " + (j + 1));

                    if (!double.TryParse(valor, out matriz[i, j]))
                    {
                        MessageBox.Show("Valor inválido. Digite um valor valido.");
                        j--;
                    }
                    else if (matriz[i, j] < 0)
                    {
                        MessageBox.Show("Valor inválida. Digite um valor valido.");
                        j--;
                    }
                    else
                    {
                        saida = "Notebook" + (i + 1) + " Loja " + (j + 1) + ": R$" + matriz[i,j];
                        LBox1.Items.Add(saida);


                        saida2 = "Média total" + (j + 1) + ": R$" + matriz[i, j];
                        LBox1.Items.Add(saida2);
                    }
                }
            }
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            LBox1.Items.Clear();
        }
    }
}
