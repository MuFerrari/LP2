﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double Peso, Altura, IMC;

        private void mtxtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mtxtAltura.Text, out Altura) || Altura <= 0)
            { 
                MessageBox.Show("Altura inválida! Insira um valor válido");
                mtxtAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = Peso / (Altura * Altura);
            IMC = Math.Round(IMC, 1);
            txtImc.Text = IMC.ToString();

            if (IMC < 18.5)
                MessageBox.Show("Você está na classificação MAGREZA");
            else if (IMC <= 24.9)
                MessageBox.Show("Você está na classificação NORMAL");
            else if (IMC <= 29.9)
                MessageBox.Show("Você está na classificação SOBREPESO COM OBESIDADE GRAU I");
            else if (IMC <= 39.9)
                MessageBox.Show("Você está na classificação OBESIDADE GRAU II");
            else
                MessageBox.Show("Você está na classificação OBESIDADE GRAVE GRAU III ");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtImc.Clear();
            mtxtPeso.Clear();
            mtxtAltura.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mtxtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mtxtPeso.Text, out Peso) || Peso <= 0)
            {
                MessageBox.Show("Peso inválido! Insira um valor válido");
                mtxtPeso.Focus();
            }
                
        }
    }
}
